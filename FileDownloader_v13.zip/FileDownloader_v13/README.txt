HOW TO USE:
Drag bruteforce log file onto "ListMasterFlex.exe"
Wait

HOW TO CONFIGURE:
Open settings.xml and edit certain values. If you break the config, just delete it and re-open the program. It will reset to default.

<BackgroundColor> - Background color of overlay in hex argb
<ForegroundColor> - Foreground color (font) of overlay in hex argb
<FontFamily>
<FontSize>
<OutputFormat> - Format string for overlay. {0} = IP, {1} = username, {2} = password
<OutputFolder>
<SaveParams> - If true, also saves "get_params.cgi"
<SaveStatus> - If true, also saves "get_status.cgi"
<Threads> - Number of threads. Higher amount means it will go faster, but it will also be more demanding. Recommended 4, not recommended above 25.
<MaxTries> - Number of times to retry connecting to the camera.
<SnapshotTimeout> - Timeout to get snapshot in ms
<PageTimeout> - Timeout to get misc pages in ms (Params, Status)
<MaintenanceEnabled> - If true, performs maintenance on the settings file. (Currently, adds a trailing slash to the output folder
<SnapshotFormat> - Image output format. Options: "png", "jpg", "bmp"