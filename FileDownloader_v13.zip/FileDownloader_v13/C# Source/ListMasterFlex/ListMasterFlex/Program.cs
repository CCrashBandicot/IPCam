﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListMasterFlex
{
    using System.Drawing;
    using System.Drawing.Imaging;
    using System.IO;

    class Program
    {
        private static void Main(string[] args)
        {
            string filename = args.Length > 0 ? String.Join(" ", args) : "bruteforce.log";

            ListMaster lm = new ListMaster(filename);
            lm.StartThreads();

            while (lm.Running)
            {
                System.Threading.Thread.Sleep(500);
            }
        }
    }
}
