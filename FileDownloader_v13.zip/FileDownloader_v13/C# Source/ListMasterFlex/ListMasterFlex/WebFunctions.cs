﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListMasterFlex
{
    public static class WebFunctions
    {
        public static string StripURL(string URL)
        {
            string strippedURL = URL.Replace("http://", "").Replace("//proc/kcore", "").Replace("/decoder_control.cgi?command=1&next_url=/proc/kcore", "").Trim();
            return strippedURL.Split('/')[0];
        }

        public static string GetAuthHeaders(string username, string password, bool full = false)
        {
            string base64 = System.Convert.ToBase64String(System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(username + ":" + password));
            if (full)
            {
                return "Authorization: Basic " + base64 + System.Environment.NewLine;
            }
            return base64;
        }
    }
}
