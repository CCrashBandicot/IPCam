﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListMasterFlex
{
    public static class ImageHelper
    {
        public static void DrawOnImage(
            this Image snapshot,
            string outputFormat,
            string strippedUrl,
            Camera c,
            Font f,
            Brush backgroundBrush,
            Brush foregroundBrush)
        {
            using (Graphics g = Graphics.FromImage(snapshot))
            {
                string stringToDraw = String.Format(outputFormat, strippedUrl, c.username, c.password);
                SizeF sizeOfText = g.MeasureString(stringToDraw, f);
                g.FillRectangle(backgroundBrush, 0, 0, sizeOfText.Width, sizeOfText.Height);
                g.DrawString(stringToDraw, f, foregroundBrush, 0, 0);
            }
        }

        public static void EasySave(this Image snapshot, string fileSaveName)
        {
            string extension = "png";
            ImageFormat imgFormat = ImageFormat.Png;

            switch (Settings.Instance.SnapshotFormat)
            {
                case "jpg":
                    extension = "jpg";
                    imgFormat = ImageFormat.Jpeg;
                    break;
                case "gif":
                    extension = "gif";
                    imgFormat = ImageFormat.Gif;
                    break;
                case "bmp": // why?
                    extension = "bmp";
                    imgFormat = ImageFormat.Bmp;
                    break;
            }

            snapshot.Save(fileSaveName + "." + extension, imgFormat);
        }
    }
}
