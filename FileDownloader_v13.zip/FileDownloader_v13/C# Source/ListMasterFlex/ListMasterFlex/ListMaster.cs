﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListMasterFlex
{
    using System.Collections.Concurrent;
    using System.Drawing;
    using System.Drawing.Imaging;
    using System.IO;
    using System.Threading;

    public class ListMaster
    {
        private static string errorMessage = "Error getting {0} for camera {1}:\r\n{2}";

        private ConcurrentStack<Camera> cameras = new ConcurrentStack<Camera>();

        private Settings s = Settings.Instance;

        private Font overlayFont;

        private Brush backgroundBrush;

        private Brush foregroundBrush;

        private string logName;

        private Thread[] threads;

        public bool Running
        {
            get
            {
                foreach (Thread t in threads)
                {
                    if (t.IsAlive)
                    {
                        return true;
                    }
                }

                return false;
            }
        }

        public ListMaster(string logname)
        {
            logName = logname;
            this.InitializeVariables();
        }

        private void InitializeVariables()
        {
            overlayFont = new Font(s.FontFamily, s.FontSize);
            backgroundBrush = new SolidBrush(ColorTranslator.FromHtml(s.BackgroundColor));
            foregroundBrush = new SolidBrush(ColorTranslator.FromHtml(s.ForegroundColor));

            List<Camera> cameraList = ListParser.Parse(logName);
            cameras.PushRange(cameraList.ToArray());

            if (!Directory.Exists(s.OutputFolder))
            {
                Directory.CreateDirectory(s.OutputFolder);
            }

            ThreadStart targetMethod = new ThreadStart(this.DoCameras);
            threads = new Thread[s.Threads];
            for (int i = 0; i < threads.Length; i++)
            {
                threads[i] = new Thread(targetMethod);
            }
        }

        public void StartThreads()
        {
            foreach (Thread t in threads)
            {
                if (t.IsAlive) continue;

                t.Start();
            }
        }

        public void StopThreads()
        {
            foreach (Thread t in threads)
            {
                if (!t.IsAlive) continue;

                t.Abort();
            }
        }

        private void DoCameras()
        {
            while (cameras.Count > 0)
            {
                Camera c;
                cameras.TryPop(out c);
                if (c == null) continue;

                for (int retries = 0; retries < s.MaxTries; retries++)
                {
                    if (this.DoSingleCamera(c)) break;
                }
            }
        }

        private bool DoSingleCamera(Camera c)
        {
            List<string> consoleOutput = new List<string>();
            string strippedUrl = WebFunctions.StripURL(c.url);

            Image snapshot;
            try
            {
                snapshot = c.GetSnapshot();
            }
            catch (Exception ex)
            {
                Console.WriteLine(errorMessage, "snapshot", strippedUrl, ex.Message);
                return false;
            }
            snapshot.DrawOnImage(s.OutputFormat, strippedUrl, c, overlayFont, backgroundBrush, foregroundBrush);

            string savedParams = "";
            if (s.SaveParams)
            {
                try
                {
                    savedParams = c.GetParams();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(errorMessage, "params", strippedUrl, ex.Message);
                    return false;
                }
            }

            string savedStatus = "";
            if (s.SaveStatus)
            {
                try
                {
                    savedStatus = c.GetStatus();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(errorMessage, "status", strippedUrl, ex.Message);
                    return false;
                }
            }

            string fileSaveName = s.OutputFolder + strippedUrl.Replace(':', '-');

            snapshot.EasySave(fileSaveName);
            if (s.SaveParams) File.WriteAllText(fileSaveName + "_params.txt", savedParams);
            if (s.SaveStatus) File.WriteAllText(fileSaveName + "_status.txt", savedStatus);

            Console.WriteLine("--- {0} has been saved!", strippedUrl);

            return true;
        }  
    }
}
