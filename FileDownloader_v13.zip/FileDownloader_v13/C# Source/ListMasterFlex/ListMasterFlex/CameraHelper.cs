﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ListMasterFlex
{
    using System.Drawing;
    using System.IO;

    public static class CameraHelper
    {
        public static string GetParams(this Camera c)
        {
            return c.GetPage("get_params.cgi");
        }

        public static string GetStatus(this Camera c)
        {
            return c.GetPage("get_status.cgi");
        }

        public static string GetPage(this Camera c, string page)
        {
            string url = WebFunctions.StripURL(c.url);
            HttpWebRequest hr = (HttpWebRequest)HttpWebRequest.Create("http://" + url + "/" + page);
            hr.Timeout = Settings.Instance.PageTimeout;
            string credentials = WebFunctions.GetAuthHeaders(c.username, c.password);
            hr.Headers.Add("Authorization", "Basic " + credentials);
            hr.PreAuthenticate = true;

            using (HttpWebResponse resp = (HttpWebResponse)hr.GetResponse())
            {
                using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                {
                    return sr.ReadToEnd();
                }
            }
        }

        public static Image GetSnapshot(this Camera c)
        {
            string url = WebFunctions.StripURL(c.url);
            HttpWebRequest hr = (HttpWebRequest)HttpWebRequest.Create("http://" + url + "/snapshot.cgi");
            hr.Timeout = Settings.Instance.SnapshotTimeout;
            string credentials = WebFunctions.GetAuthHeaders(c.username, c.password);
            hr.Headers.Add("Authorization", "Basic " + credentials);
            hr.PreAuthenticate = true;

            using (HttpWebResponse resp = (HttpWebResponse)hr.GetResponse())
            {
                Image snapshot = Image.FromStream(resp.GetResponseStream());
                return snapshot;
            }
        }
    }
}
