﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListMasterFlex
{
    using System.IO;

    public static class ListParser
    {
        public static List<Camera> Parse(string list)
        {
            List<Camera> cameraList = new List<Camera>();

            try
            {
                string[] file = File.ReadAllLines(list);
                foreach (string cam in file)
                {
                    Camera c = new Camera();
                    string[] splitCam = cam.Split('-');
                    c.url = splitCam[0].Trim();

                    string[] splitCreds = splitCam[1].Trim().Split(':');
                    c.username = splitCreds[0];
                    if (splitCreds.Length > 1)
                    {
                        c.password = splitCreds[1];
                    }

                    cameraList.Add(c);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "\r\n" + ex.StackTrace);
            }

            return cameraList;
        }
    }
}
