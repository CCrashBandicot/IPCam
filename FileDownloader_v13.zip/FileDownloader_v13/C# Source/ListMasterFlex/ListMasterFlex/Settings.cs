﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListMasterFlex
{
    using System.Drawing;
    using System.IO;
    using System.Xml.Serialization;

    public class Settings
    {
        #region Serializing
        public static Settings Instance
        {
            get
            {
                if (_Instance == null)
                {
                    _Instance = Load();
                }

                return _Instance;
            }
        }

        private static Settings _Instance;

        public static Settings Load(string filename = "settings.xml")
        {
            Settings s = null;

            if (!File.Exists(filename))
            {
                s = new Settings();
                s.Save(filename);
                return s;
            }

            using (StreamReader sr = new StreamReader(filename))
            {
                XmlSerializer xs = new XmlSerializer(typeof(Settings));
                s = (Settings)xs.Deserialize(sr);
                if(s.MaintenanceEnabled) s.Maintenance();
            }

            return s == null ? new Settings() : s;
        }

        public void Save(string filename = "settings.xml")
        {
            using (StreamWriter sw = new StreamWriter(filename))
            {
                XmlSerializer xs = new XmlSerializer(typeof(Settings));
                xs.Serialize(sw, this);
            }
        }

        private void Maintenance()
        {
            if (!this.OutputFolder.EndsWith("/") || !this.OutputFolder.EndsWith("\\"))
            {
                this.OutputFolder += "/";
            }
        }
        #endregion

        public string BackgroundColor = "#77000000";

        public string ForegroundColor = "#FFFF0000";

        public string FontFamily = "Tahoma";

        public int FontSize = 12;

        public string OutputFormat = "{0}\r\n{1}:{2}";

        public string OutputFolder = "Snapshots/";

        public bool SaveParams = true;

        public bool SaveStatus = false;

        public int Threads = 4;

        public int MaxTries = 2;

        public int SnapshotTimeout = 1500;

        public int PageTimeout = 1500;

        public bool MaintenanceEnabled = true;

        public string SnapshotFormat = "png";
    }
}
