﻿namespace FileDownloader
{
    partial class FormSettingsNew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.General = new System.Windows.Forms.TabPage();
            this.Bruteforce = new System.Windows.Forms.TabPage();
            this.Download = new System.Windows.Forms.TabPage();
            this.btnDefault = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.chkDownloadAutoRemove = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.nudDownloads = new System.Windows.Forms.NumericUpDown();
            this.chkAutoCancel = new System.Windows.Forms.CheckBox();
            this.chkRetry = new System.Windows.Forms.CheckBox();
            this.nudWordCutoff = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.nudBruteforcers = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBuffer = new System.Windows.Forms.MaskedTextBox();
            this.txtOffset = new System.Windows.Forms.MaskedTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.chkAutoBruteforce = new System.Windows.Forms.CheckBox();
            this.chkStrict = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chkGeneralFileSorting = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtBruteforceLogFormat = new System.Windows.Forms.TextBox();
            this.lblBruteforceLogExample = new System.Windows.Forms.Label();
            this.chkGeneralDefaultPassword = new System.Windows.Forms.CheckBox();
            this.txtGeneralDefaultPassword = new System.Windows.Forms.TextBox();
            this.tt = new System.Windows.Forms.ToolTip(this.components);
            this.tabControl1.SuspendLayout();
            this.General.SuspendLayout();
            this.Bruteforce.SuspendLayout();
            this.Download.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudDownloads)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudWordCutoff)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBruteforcers)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.General);
            this.tabControl1.Controls.Add(this.Bruteforce);
            this.tabControl1.Controls.Add(this.Download);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(409, 232);
            this.tabControl1.TabIndex = 0;
            // 
            // General
            // 
            this.General.Controls.Add(this.txtGeneralDefaultPassword);
            this.General.Controls.Add(this.chkGeneralDefaultPassword);
            this.General.Controls.Add(this.chkGeneralFileSorting);
            this.General.Location = new System.Drawing.Point(4, 22);
            this.General.Name = "General";
            this.General.Padding = new System.Windows.Forms.Padding(3);
            this.General.Size = new System.Drawing.Size(401, 206);
            this.General.TabIndex = 0;
            this.General.Text = "General";
            this.General.UseVisualStyleBackColor = true;
            // 
            // Bruteforce
            // 
            this.Bruteforce.Controls.Add(this.lblBruteforceLogExample);
            this.Bruteforce.Controls.Add(this.txtBruteforceLogFormat);
            this.Bruteforce.Controls.Add(this.label6);
            this.Bruteforce.Controls.Add(this.groupBox1);
            this.Bruteforce.Controls.Add(this.chkRetry);
            this.Bruteforce.Controls.Add(this.nudBruteforcers);
            this.Bruteforce.Controls.Add(this.label4);
            this.Bruteforce.Controls.Add(this.chkAutoBruteforce);
            this.Bruteforce.Controls.Add(this.chkStrict);
            this.Bruteforce.Location = new System.Drawing.Point(4, 22);
            this.Bruteforce.Name = "Bruteforce";
            this.Bruteforce.Padding = new System.Windows.Forms.Padding(3);
            this.Bruteforce.Size = new System.Drawing.Size(401, 206);
            this.Bruteforce.TabIndex = 1;
            this.Bruteforce.Text = "Bruteforce";
            this.Bruteforce.UseVisualStyleBackColor = true;
            // 
            // Download
            // 
            this.Download.Controls.Add(this.chkDownloadAutoRemove);
            this.Download.Controls.Add(this.label3);
            this.Download.Controls.Add(this.nudDownloads);
            this.Download.Controls.Add(this.chkAutoCancel);
            this.Download.Location = new System.Drawing.Point(4, 22);
            this.Download.Name = "Download";
            this.Download.Size = new System.Drawing.Size(401, 206);
            this.Download.TabIndex = 2;
            this.Download.Text = "Download";
            this.Download.UseVisualStyleBackColor = true;
            // 
            // btnDefault
            // 
            this.btnDefault.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnDefault.Location = new System.Drawing.Point(12, 238);
            this.btnDefault.Name = "btnDefault";
            this.btnDefault.Size = new System.Drawing.Size(60, 23);
            this.btnDefault.TabIndex = 10;
            this.btnDefault.Text = "Defaults";
            this.btnDefault.UseVisualStyleBackColor = true;
            this.btnDefault.Click += new System.EventHandler(this.btnDefault_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Location = new System.Drawing.Point(336, 238);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(60, 23);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Location = new System.Drawing.Point(270, 238);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(60, 23);
            this.btnSave.TabIndex = 8;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // chkDownloadAutoRemove
            // 
            this.chkDownloadAutoRemove.AutoSize = true;
            this.chkDownloadAutoRemove.Location = new System.Drawing.Point(8, 57);
            this.chkDownloadAutoRemove.Name = "chkDownloadAutoRemove";
            this.chkDownloadAutoRemove.Size = new System.Drawing.Size(160, 17);
            this.chkDownloadAutoRemove.TabIndex = 8;
            this.chkDownloadAutoRemove.Text = "Remove from list when done";
            this.tt.SetToolTip(this.chkDownloadAutoRemove, "If enabled, deletes the download from the download list when complete");
            this.chkDownloadAutoRemove.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Concurrent downloads:";
            // 
            // nudDownloads
            // 
            this.nudDownloads.Location = new System.Drawing.Point(129, 8);
            this.nudDownloads.Name = "nudDownloads";
            this.nudDownloads.Size = new System.Drawing.Size(56, 20);
            this.nudDownloads.TabIndex = 6;
            this.tt.SetToolTip(this.nudDownloads, "Quantity of downloads happening at once. May require restart to function correctl" +
        "y.");
            // 
            // chkAutoCancel
            // 
            this.chkAutoCancel.AutoSize = true;
            this.chkAutoCancel.Location = new System.Drawing.Point(8, 34);
            this.chkAutoCancel.Name = "chkAutoCancel";
            this.chkAutoCancel.Size = new System.Drawing.Size(129, 17);
            this.chkAutoCancel.TabIndex = 5;
            this.chkAutoCancel.Text = "Auto cancel at 4.5MB";
            this.tt.SetToolTip(this.chkAutoCancel, "If enabled, stops download at or above 4.5MB");
            this.chkAutoCancel.UseVisualStyleBackColor = true;
            // 
            // chkRetry
            // 
            this.chkRetry.AutoSize = true;
            this.chkRetry.Location = new System.Drawing.Point(194, 52);
            this.chkRetry.Name = "chkRetry";
            this.chkRetry.Size = new System.Drawing.Size(153, 17);
            this.chkRetry.TabIndex = 21;
            this.chkRetry.Text = "Retry if server unreachable";
            this.tt.SetToolTip(this.chkRetry, "If enabled, re-bruteforces the file (after a period of time) if the server is dow" +
        "n.");
            this.chkRetry.UseVisualStyleBackColor = true;
            // 
            // nudWordCutoff
            // 
            this.nudWordCutoff.Location = new System.Drawing.Point(116, 70);
            this.nudWordCutoff.Name = "nudWordCutoff";
            this.nudWordCutoff.Size = new System.Drawing.Size(50, 20);
            this.nudWordCutoff.TabIndex = 19;
            this.tt.SetToolTip(this.nudWordCutoff, "Minimum amount of letters in a word for it to be considered\r\nIf this is set to \"2" +
        "\", single-letter words found in downloaded files will be excluded and therefore " +
        "not used as a username or password.");
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 72);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 13);
            this.label5.TabIndex = 20;
            this.label5.Text = "Word cutoff:";
            // 
            // nudBruteforcers
            // 
            this.nudBruteforcers.Location = new System.Drawing.Point(246, 70);
            this.nudBruteforcers.Name = "nudBruteforcers";
            this.nudBruteforcers.Size = new System.Drawing.Size(50, 20);
            this.nudBruteforcers.TabIndex = 14;
            this.tt.SetToolTip(this.nudBruteforcers, "Quantity of files to bruteforce at the same time");
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(191, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "Threads:";
            // 
            // txtBuffer
            // 
            this.txtBuffer.Location = new System.Drawing.Point(51, 44);
            this.txtBuffer.Name = "txtBuffer";
            this.txtBuffer.Size = new System.Drawing.Size(115, 20);
            this.txtBuffer.TabIndex = 17;
            this.tt.SetToolTip(this.txtBuffer, "Advanced: How many bytes of the file to read");
            this.txtBuffer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ValidateHexOnPress);
            // 
            // txtOffset
            // 
            this.txtOffset.Location = new System.Drawing.Point(51, 18);
            this.txtOffset.Name = "txtOffset";
            this.txtOffset.Size = new System.Drawing.Size(115, 20);
            this.txtOffset.TabIndex = 16;
            this.tt.SetToolTip(this.txtOffset, "Advanced: Where to start reading the downloaded file");
            this.txtOffset.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ValidateHexOnPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 15;
            this.label2.Text = "Buffer:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Offset:";
            // 
            // chkAutoBruteforce
            // 
            this.chkAutoBruteforce.AutoSize = true;
            this.chkAutoBruteforce.Location = new System.Drawing.Point(194, 6);
            this.chkAutoBruteforce.Name = "chkAutoBruteforce";
            this.chkAutoBruteforce.Size = new System.Drawing.Size(99, 17);
            this.chkAutoBruteforce.TabIndex = 11;
            this.chkAutoBruteforce.Text = "Auto bruteforce";
            this.tt.SetToolTip(this.chkAutoBruteforce, "If enabled, automatically begins to bruteforce downloaded files");
            this.chkAutoBruteforce.UseVisualStyleBackColor = true;
            // 
            // chkStrict
            // 
            this.chkStrict.AutoSize = true;
            this.chkStrict.Location = new System.Drawing.Point(194, 29);
            this.chkStrict.Name = "chkStrict";
            this.chkStrict.Size = new System.Drawing.Size(180, 17);
            this.chkStrict.TabIndex = 12;
            this.chkStrict.Text = "Strict mode (avoid excess logins)";
            this.tt.SetToolTip(this.chkStrict, "If enabled, stops bruteforcing the file if finding credentials is unlikely");
            this.chkStrict.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtOffset);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.nudWordCutoff);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtBuffer);
            this.groupBox1.Location = new System.Drawing.Point(8, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(180, 104);
            this.groupBox1.TabIndex = 22;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Searching";
            // 
            // chkGeneralFileSorting
            // 
            this.chkGeneralFileSorting.AutoSize = true;
            this.chkGeneralFileSorting.Location = new System.Drawing.Point(8, 6);
            this.chkGeneralFileSorting.Name = "chkGeneralFileSorting";
            this.chkGeneralFileSorting.Size = new System.Drawing.Size(76, 17);
            this.chkGeneralFileSorting.TabIndex = 0;
            this.chkGeneralFileSorting.Text = "File sorting";
            this.tt.SetToolTip(this.chkGeneralFileSorting, "If enabled, sorts downloaded files into folders depending on status\r\n Failed (too" +
        " small) -> \"Bad\"\r\n Failed (not found) -> \"Possible\"\r\n Completed -> \"Good\"\r\n \r\n ");
            this.chkGeneralFileSorting.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 113);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 13);
            this.label6.TabIndex = 23;
            this.label6.Text = "Log format:";
            // 
            // txtBruteforceLogFormat
            // 
            this.txtBruteforceLogFormat.Location = new System.Drawing.Point(8, 129);
            this.txtBruteforceLogFormat.Name = "txtBruteforceLogFormat";
            this.txtBruteforceLogFormat.Size = new System.Drawing.Size(180, 20);
            this.txtBruteforceLogFormat.TabIndex = 24;
            this.txtBruteforceLogFormat.Text = "http://{0}/ - {1}:{2}";
            this.tt.SetToolTip(this.txtBruteforceLogFormat, "Change how stuff is saved to the log");
            this.txtBruteforceLogFormat.TextChanged += new System.EventHandler(this.txtBruteforceLogFormat_TextChanged);
            // 
            // lblBruteforceLogExample
            // 
            this.lblBruteforceLogExample.AutoSize = true;
            this.lblBruteforceLogExample.Location = new System.Drawing.Point(5, 152);
            this.lblBruteforceLogExample.Name = "lblBruteforceLogExample";
            this.lblBruteforceLogExample.Size = new System.Drawing.Size(156, 13);
            this.lblBruteforceLogExample.TabIndex = 25;
            this.lblBruteforceLogExample.Text = "http://127.0.0.1/ - admin:admin";
            // 
            // chkGeneralDefaultPassword
            // 
            this.chkGeneralDefaultPassword.AutoSize = true;
            this.chkGeneralDefaultPassword.Location = new System.Drawing.Point(8, 29);
            this.chkGeneralDefaultPassword.Name = "chkGeneralDefaultPassword";
            this.chkGeneralDefaultPassword.Size = new System.Drawing.Size(141, 17);
            this.chkGeneralDefaultPassword.TabIndex = 1;
            this.chkGeneralDefaultPassword.Text = "Default password check";
            this.tt.SetToolTip(this.chkGeneralDefaultPassword, "If enabled, attempts to use supplied default credentials before downloading from " +
        "the camera");
            this.chkGeneralDefaultPassword.UseVisualStyleBackColor = true;
            this.chkGeneralDefaultPassword.CheckedChanged += new System.EventHandler(this.chkGeneralDefaultPassword_CheckedChanged);
            // 
            // txtGeneralDefaultPassword
            // 
            this.txtGeneralDefaultPassword.Enabled = false;
            this.txtGeneralDefaultPassword.Location = new System.Drawing.Point(8, 52);
            this.txtGeneralDefaultPassword.Multiline = true;
            this.txtGeneralDefaultPassword.Name = "txtGeneralDefaultPassword";
            this.txtGeneralDefaultPassword.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtGeneralDefaultPassword.Size = new System.Drawing.Size(141, 60);
            this.txtGeneralDefaultPassword.TabIndex = 2;
            this.txtGeneralDefaultPassword.Text = "admin:\r\nadmin:admin\r\nadmin:12345\r\nadmin:123456";
            this.tt.SetToolTip(this.txtGeneralDefaultPassword, "Default passwords to attempt to use before downloading. \r\nFormat should be:\r\nuser" +
        "name:password\r\nseparate each entry with a new line");
            // 
            // FormSettingsNew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(408, 273);
            this.Controls.Add(this.btnDefault);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.tabControl1);
            this.Name = "FormSettingsNew";
            this.Text = "Settings";
            this.Load += new System.EventHandler(this.FormSettingsNew_Load);
            this.tabControl1.ResumeLayout(false);
            this.General.ResumeLayout(false);
            this.General.PerformLayout();
            this.Bruteforce.ResumeLayout(false);
            this.Bruteforce.PerformLayout();
            this.Download.ResumeLayout(false);
            this.Download.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudDownloads)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudWordCutoff)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBruteforcers)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage General;
        private System.Windows.Forms.TabPage Bruteforce;
        private System.Windows.Forms.TabPage Download;
        private System.Windows.Forms.Button btnDefault;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.CheckBox chkDownloadAutoRemove;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown nudDownloads;
        private System.Windows.Forms.CheckBox chkAutoCancel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.MaskedTextBox txtOffset;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown nudWordCutoff;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.MaskedTextBox txtBuffer;
        private System.Windows.Forms.CheckBox chkRetry;
        private System.Windows.Forms.NumericUpDown nudBruteforcers;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox chkAutoBruteforce;
        private System.Windows.Forms.CheckBox chkStrict;
        private System.Windows.Forms.CheckBox chkGeneralFileSorting;
        private System.Windows.Forms.Label lblBruteforceLogExample;
        private System.Windows.Forms.TextBox txtBruteforceLogFormat;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtGeneralDefaultPassword;
        private System.Windows.Forms.CheckBox chkGeneralDefaultPassword;
        private System.Windows.Forms.ToolTip tt;
    }
}