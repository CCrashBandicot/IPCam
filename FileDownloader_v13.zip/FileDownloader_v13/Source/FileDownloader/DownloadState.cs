﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileDownloader
{
    public class DownloadState
    {
        public int totalRead = 0;

        public bool done = false;

        public bool cancelled = false;

        public string status = "waiting...";

        public string url = "";
    }
}
