﻿namespace FileDownloader
{
    partial class FormSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.chkAutoBruteforce = new System.Windows.Forms.CheckBox();
            this.chkAutoCancel = new System.Windows.Forms.CheckBox();
            this.chkStrict = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chkRetry = new System.Windows.Forms.CheckBox();
            this.nudWordCutoff = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.nudBruteforcers = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBuffer = new System.Windows.Forms.MaskedTextBox();
            this.txtOffset = new System.Windows.Forms.MaskedTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chkDownloadAutoRemove = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.nudDownloads = new System.Windows.Forms.NumericUpDown();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnDefault = new System.Windows.Forms.Button();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudWordCutoff)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBruteforcers)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudDownloads)).BeginInit();
            this.SuspendLayout();
            // 
            // chkAutoBruteforce
            // 
            this.chkAutoBruteforce.AutoSize = true;
            this.chkAutoBruteforce.Location = new System.Drawing.Point(9, 66);
            this.chkAutoBruteforce.Name = "chkAutoBruteforce";
            this.chkAutoBruteforce.Size = new System.Drawing.Size(100, 17);
            this.chkAutoBruteforce.TabIndex = 0;
            this.chkAutoBruteforce.Text = "Auto Bruteforce";
            this.toolTip.SetToolTip(this.chkAutoBruteforce, "Automatically begins bruteforcing downloaded files");
            this.chkAutoBruteforce.UseVisualStyleBackColor = true;
            // 
            // chkAutoCancel
            // 
            this.chkAutoCancel.AutoSize = true;
            this.chkAutoCancel.Location = new System.Drawing.Point(9, 43);
            this.chkAutoCancel.Name = "chkAutoCancel";
            this.chkAutoCancel.Size = new System.Drawing.Size(130, 17);
            this.chkAutoCancel.TabIndex = 1;
            this.chkAutoCancel.Text = "Auto Cancel at 4.5MB";
            this.toolTip.SetToolTip(this.chkAutoCancel, "Automatically stops the download once it reaches 4.5MB");
            this.chkAutoCancel.UseVisualStyleBackColor = true;
            // 
            // chkStrict
            // 
            this.chkStrict.AutoSize = true;
            this.chkStrict.Location = new System.Drawing.Point(115, 66);
            this.chkStrict.Name = "chkStrict";
            this.chkStrict.Size = new System.Drawing.Size(53, 17);
            this.chkStrict.TabIndex = 2;
            this.chkStrict.Text = "Strict ";
            this.toolTip.SetToolTip(this.chkStrict, "Avoids using excess traffic and false-postives. It is highly recommended to keep " +
        "this on.");
            this.chkStrict.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkRetry);
            this.groupBox1.Controls.Add(this.nudWordCutoff);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.nudBruteforcers);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtBuffer);
            this.groupBox1.Controls.Add(this.txtOffset);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.chkAutoBruteforce);
            this.groupBox1.Controls.Add(this.chkStrict);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(171, 148);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bruteforce";
            // 
            // chkRetry
            // 
            this.chkRetry.AutoSize = true;
            this.chkRetry.Location = new System.Drawing.Point(9, 82);
            this.chkRetry.Name = "chkRetry";
            this.chkRetry.Size = new System.Drawing.Size(51, 17);
            this.chkRetry.TabIndex = 10;
            this.chkRetry.Text = "Retry";
            this.toolTip.SetToolTip(this.chkRetry, "Retries bruteforcing if the connection to the server times out");
            this.chkRetry.UseVisualStyleBackColor = true;
            // 
            // nudWordCutoff
            // 
            this.nudWordCutoff.Location = new System.Drawing.Point(115, 128);
            this.nudWordCutoff.Name = "nudWordCutoff";
            this.nudWordCutoff.Size = new System.Drawing.Size(50, 20);
            this.nudWordCutoff.TabIndex = 8;
            this.toolTip.SetToolTip(this.nudWordCutoff, "Words with less characters than this value will be excluded. Set to 0 for disable" +
        "d, although this is not recommended.");
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(42, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Word Cutoff:";
            // 
            // nudBruteforcers
            // 
            this.nudBruteforcers.Location = new System.Drawing.Point(115, 102);
            this.nudBruteforcers.Name = "nudBruteforcers";
            this.nudBruteforcers.Size = new System.Drawing.Size(50, 20);
            this.nudBruteforcers.TabIndex = 4;
            this.toolTip.SetToolTip(this.nudBruteforcers, "How many bruteforcers to run in the background");
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(60, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Threads:";
            // 
            // txtBuffer
            // 
            this.txtBuffer.Location = new System.Drawing.Point(50, 40);
            this.txtBuffer.Name = "txtBuffer";
            this.txtBuffer.Size = new System.Drawing.Size(115, 20);
            this.txtBuffer.TabIndex = 6;
            this.toolTip.SetToolTip(this.txtBuffer, "How much of the file to read");
            this.txtBuffer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ValidateHexOnPress);
            // 
            // txtOffset
            // 
            this.txtOffset.Location = new System.Drawing.Point(50, 14);
            this.txtOffset.Name = "txtOffset";
            this.txtOffset.Size = new System.Drawing.Size(115, 20);
            this.txtOffset.TabIndex = 5;
            this.toolTip.SetToolTip(this.txtOffset, "Where to start reading the file");
            this.txtOffset.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ValidateHexOnPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Buffer:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Offset:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.chkDownloadAutoRemove);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.nudDownloads);
            this.groupBox2.Controls.Add(this.chkAutoCancel);
            this.groupBox2.Location = new System.Drawing.Point(189, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(211, 83);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Downloads";
            // 
            // chkDownloadAutoRemove
            // 
            this.chkDownloadAutoRemove.AutoSize = true;
            this.chkDownloadAutoRemove.Location = new System.Drawing.Point(9, 60);
            this.chkDownloadAutoRemove.Name = "chkDownloadAutoRemove";
            this.chkDownloadAutoRemove.Size = new System.Drawing.Size(160, 17);
            this.chkDownloadAutoRemove.TabIndex = 4;
            this.chkDownloadAutoRemove.Text = "Remove from list when done";
            this.chkDownloadAutoRemove.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Concurrent Downloads:";
            // 
            // nudDownloads
            // 
            this.nudDownloads.Location = new System.Drawing.Point(130, 15);
            this.nudDownloads.Name = "nudDownloads";
            this.nudDownloads.Size = new System.Drawing.Size(56, 20);
            this.nudDownloads.TabIndex = 2;
            this.toolTip.SetToolTip(this.nudDownloads, "Quantity of files downloading at the same time");
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(274, 140);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(60, 23);
            this.btnSave.TabIndex = 5;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(340, 140);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(60, 23);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnDefault
            // 
            this.btnDefault.Location = new System.Drawing.Point(189, 140);
            this.btnDefault.Name = "btnDefault";
            this.btnDefault.Size = new System.Drawing.Size(60, 23);
            this.btnDefault.TabIndex = 7;
            this.btnDefault.Text = "Defaults";
            this.btnDefault.UseVisualStyleBackColor = true;
            this.btnDefault.Click += new System.EventHandler(this.btnDefault_Click);
            // 
            // toolTip
            // 
            this.toolTip.AutomaticDelay = 100;
            this.toolTip.AutoPopDelay = 10000;
            this.toolTip.InitialDelay = 100;
            this.toolTip.ReshowDelay = 20;
            this.toolTip.ShowAlways = true;
            // 
            // FormSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(412, 172);
            this.Controls.Add(this.btnDefault);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormSettings";
            this.Text = "Settings";
            this.Load += new System.EventHandler(this.FormSettings_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudWordCutoff)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudBruteforcers)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudDownloads)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckBox chkAutoBruteforce;
        private System.Windows.Forms.CheckBox chkAutoCancel;
        private System.Windows.Forms.CheckBox chkStrict;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox txtBuffer;
        private System.Windows.Forms.MaskedTextBox txtOffset;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnDefault;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown nudDownloads;
        private System.Windows.Forms.NumericUpDown nudBruteforcers;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox chkDownloadAutoRemove;
        private System.Windows.Forms.NumericUpDown nudWordCutoff;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.CheckBox chkRetry;
    }
}