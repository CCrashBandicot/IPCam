﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FileDownloader
{
    using System.Globalization;

    using FileDownloader.Properties;

    public partial class FormSettings : Form
    {
        public FormSettings()
        {
            InitializeComponent();
        }

        private void ValidateHexOnPress(object sender, KeyPressEventArgs e)
        {
            char c = e.KeyChar;
            if (c != '\b' && !((c >= 'a' && c <= 'f') || (c >= '0' && c <= '9')))
            {
                e.Handled = true;
            }
        }

        private void FormSettings_Load(object sender, EventArgs e)
        {
            this.SetForm();
        }

        private void SetForm()
        {
            // bruteforce
            txtBuffer.Text = Settings.Default.bruteforceBuffer.ToString("x8");
            txtOffset.Text = Settings.Default.bruteforceOffset.ToString("x8");
            chkAutoBruteforce.Checked = Settings.Default.bruteforceAuto;
            chkStrict.Checked = Settings.Default.bruteforceStrict;
            nudBruteforcers.Value = Settings.Default.bruteforceConcurrent;
            nudWordCutoff.Value = Settings.Default.bruteforceMinSize;
            chkRetry.Checked = Settings.Default.bruteforceRetry;

            // download
            chkAutoCancel.Checked = Settings.Default.downloadAutoCancel;
            chkDownloadAutoRemove.Checked = Settings.Default.downloadAutoRemove;
            nudDownloads.Value = Settings.Default.downloadConcurrent;
        }

        private void btnDefault_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.Reset();
            this.SetForm();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            this.SaveSettings();
            this.Close();
        }

        private void SaveSettings()
        {
            Settings.Default.bruteforceBuffer = Int32.Parse(txtBuffer.Text, NumberStyles.AllowHexSpecifier);
            Settings.Default.bruteforceOffset = Int32.Parse(txtOffset.Text, NumberStyles.AllowHexSpecifier);
            Settings.Default.bruteforceAuto = chkAutoBruteforce.Checked;
            Settings.Default.bruteforceStrict = chkStrict.Checked;
            Settings.Default.bruteforceConcurrent = (int)nudBruteforcers.Value;
            Settings.Default.bruteforceMinSize = (int)nudWordCutoff.Value;
            Settings.Default.bruteforceRetry = chkRetry.Checked;

            Settings.Default.downloadAutoCancel = chkAutoCancel.Checked;
            Settings.Default.downloadConcurrent = (int)nudDownloads.Value;
            Settings.Default.downloadAutoRemove = chkDownloadAutoRemove.Checked;
            Settings.Default.Save();

            MessageBox.Show("Settings saved!");
        }
    }
}
